script.on_event(defines.events.on_console_chat, function(event)
  game.write_file("ChatLog.log","\r\n[" .. game.players[event.player_index].name .. "]" .. event.message, true)
end)